namespace BLL;
using Models.Student;
using DAL;

public class StudentManager
{
    public List<Student> GetAllStudent()
    {
        List<Student> slist=new List<Student>();
        slist=StudentDBManager.GetAllStudent();
        return slist;
    }

    public bool Insert(Student s)
    {
        bool y=StudentDBManager.Insert(s);
        return y;
    }

    public bool Delete(Student s)
    {
        bool y=StudentDBManager.Delete(s);
        return y;
    }

    public bool Update(Student s)
    {
        bool y=StudentDBManager.Update(s);
        return y;
    }


}