namespace Models.Student;

public class Student{
    public int Roll_No{get;set;}
    public string Sname{get;set;}
    public string Mob_no{get;set;}
    public string Email{get;set;}
}