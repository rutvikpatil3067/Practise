using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using StudentApp.Models;
using Models.Student;
using BLL;
using DAL;

namespace StudentApp.Controllers;

public class StudentController : Controller
{
    private readonly ILogger<StudentController> _logger;

    public StudentController(ILogger<StudentController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        StudentManager mgr=new StudentManager();
        List<Student> student=mgr.GetAllStudent();
        ViewData["Student"]=student;
        return View();
    }

    [HttpGet]
    public IActionResult Insert()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Insert(int roll_no, string name, string mob_no,string email)
    {
        List<Student> slist=new List<Student>();
        Student s=new Student();
        s.Roll_No=roll_no;
        s.Sname=name;
        s.Mob_no=mob_no;
        s.Email=email;

        StudentManager smgr=new StudentManager();
        bool x=smgr.Insert(s);
        Console.WriteLine(x);


        string msg="Student Data Inserted Successfully";

        ViewData["IMsg"]=msg;
        return View();
    }

    [HttpGet]
    public IActionResult Delete()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Delete(int roll_no)
    {
        Student s=new Student();
        s.Roll_No=roll_no;

        if(roll_no!=0)
        {
            bool x=StudentDBManager.Delete(s);
            Console.WriteLine(x);
        }

        string msg="Deleted Successfully";
        ViewData["IMsg"]=msg;


        return View();
    }

    [HttpGet]
    public IActionResult Update()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Update(int roll_no, string name, string mob_no,string email)
    {
        List<Student> slist=new List<Student>();
        Student s=new Student();
        s.Roll_No=roll_no;
        s.Sname=name;
        s.Mob_no=mob_no;
        s.Email=email;

        StudentManager smgr=new StudentManager();
        bool x=smgr.Update(s);
        Console.WriteLine(x);


        string msg="Student Data Updated Successfully";

        ViewData["IMsg"]=msg;
        return View();
      
    }

    


    
}
