namespace DAL;
using Models.Student;
using MySql.Data.MySqlClient;

public class StudentDBManager
{
    public static string conString="server=localhost;port=3306;user=root;password=Yogita@1711;database=Yogita";

    public static List<Student> GetAllStudent()
    {
        List<Student> slist = new List<Student>();
        MySqlConnection connection=new MySqlConnection();
        connection.ConnectionString=conString;

        string query="Select * from Student";

        MySqlCommand cmd=new MySqlCommand(query,connection);

        try
        {
            connection.Open();
            MySqlDataReader reader=cmd.ExecuteReader();
            while(reader.Read())
            {
                int rn=int.Parse(reader["roll_no"].ToString());
                string nm=reader["sname"].ToString();
                string mb=reader["mob_no"].ToString();
                string email=reader["email"].ToString();

                Student stu=new Student();
                stu.Roll_No=rn;
                stu.Sname=nm;
                stu.Mob_no=mb;
                stu.Email=email;

                slist.Add(stu);
            }
            reader.Close();
        }

        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }

        finally{
            connection.Close();
        }
        return slist;
    }

    public static bool Insert(Student s)
    {
        bool status = false;
        MySqlConnection connection=new MySqlConnection();
        connection.ConnectionString=conString;
        string query="Insert into student(roll_no,sname,mob_no,email)Values('"+s.Roll_No+"','"+s.Sname+"','"+s.Mob_no+"','"+s.Email+"')";

        try{
            connection.Open();
            MySqlCommand cmd=new MySqlCommand(query,connection);
            cmd.ExecuteNonQuery();
            status=true;
        }

        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }

        finally{
            connection.Close();
        }
        return status;
    }

    public static bool Delete(Student s)
    {
        bool status=false;
        MySqlConnection connection=new MySqlConnection();
        connection.ConnectionString=conString;

        string query="delete from student where roll_no="+s.Roll_No;

        try{
            connection.Open();
            MySqlCommand cmd=new MySqlCommand(query,connection);
            cmd.ExecuteNonQuery();
            status=true;
        }
        
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }

        finally{
            connection.Close();
        }
        return status;
    }

    public static bool Update(Student s)
    {
        bool status=false;
        MySqlConnection connection=new MySqlConnection();
        connection.ConnectionString=conString;

        string query="update student set sname='"+s.Sname+"', mob_no='"+s.Mob_no+"', email='"+s.Email+"' where roll_no="+s.Roll_No;

        try{
            connection.Open();
            MySqlCommand cmd=new MySqlCommand(query,connection);
            cmd.ExecuteNonQuery();
            status=true;
        }
        
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
        }

        finally{
            connection.Close();
        }
        return status;
    }
}